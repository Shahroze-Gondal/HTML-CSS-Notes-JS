function myFunction(val){
    form.input_name.value = form.input_name.value + val;
};